#!/usr/bin/env python3
"""MoonTreach: repository-local CI accelerator and read-only PR evidence tool."""
from __future__ import annotations
import argparse, fnmatch, json, os, re, shlex, subprocess, sys, time
from collections import defaultdict
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

ROOT = Path(os.environ.get('MOONTREACH_ROOT', Path.cwd())).resolve()
CONFIG = ROOT / '.moon-treach' / 'config.json'

class MoonTreachError(Exception):
    pass

def load_config():
    try: data = json.loads(CONFIG.read_text(encoding='utf-8'))
    except FileNotFoundError as e: raise MoonTreachError(f'Missing config: {CONFIG}') from e
    except json.JSONDecodeError as e: raise MoonTreachError(f'Invalid config JSON: {e}') from e
    validate_config(data)
    return data

def validate_config(data):
    if not isinstance(data, dict) or data.get('schema_version') != 1: raise MoonTreachError('schema_version must be 1')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', str(data.get('repository',''))): raise MoonTreachError('repository must use owner/name')
    if not isinstance(data.get('suites'), list): raise MoonTreachError('suites must be an array')
    seen=set()
    for suite in data['suites']:
        if not isinstance(suite,dict): raise MoonTreachError('suite must be an object')
        sid=suite.get('id')
        if not isinstance(sid,str) or not re.fullmatch(r'[a-z0-9][a-z0-9._-]{0,63}',sid) or sid in seen: raise MoonTreachError(f'invalid or duplicate suite id: {sid}')
        seen.add(sid)
        if not isinstance(suite.get('paths'),list) or not suite['paths'] or not all(isinstance(x,str) and x for x in suite['paths']): raise MoonTreachError(f'{sid}: paths must be non-empty strings')
        if not isinstance(suite.get('steps'),list) or not suite['steps']: raise MoonTreachError(f'{sid}: steps must not be empty')
        timeout=suite.get('timeout_seconds',1200)
        if not isinstance(timeout,int) or not 1 <= timeout <= 14400: raise MoonTreachError(f'{sid}: invalid timeout_seconds')
        if suite.get('runs_on','ubuntu-latest') not in ('ubuntu-latest','windows-latest','macos-latest'): raise MoonTreachError(f'{sid}: unsupported runner')
        for step in suite['steps']:
            if not isinstance(step,dict) or not isinstance(step.get('name'),str) or not isinstance(step.get('command'),list) or not step['command'] or not all(isinstance(x,str) for x in step['command']): raise MoonTreachError(f'{sid}: every step needs a name and argv command array')
            cwd=step.get('cwd','.')
            if not isinstance(cwd,str) or Path(cwd).is_absolute() or '..' in Path(cwd).parts: raise MoonTreachError(f'{sid}: cwd must remain inside repository')
    fleet=data.get('fleet',[])
    if not isinstance(fleet,list) or not all(isinstance(x,str) and re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',x) for x in fleet): raise MoonTreachError('fleet must contain owner/name ids')

def path_matches(path, pattern):
    path=path.replace('\\','/').removeprefix('./'); pattern=pattern.replace('\\','/').removeprefix('./')
    return fnmatch.fnmatchcase(path,pattern) or (pattern.startswith('**/') and fnmatch.fnmatchcase(path,pattern[3:]))

def select_suites(config, paths, force_all=False, planning_error=None):
    suites=config['suites']
    if force_all or planning_error or not paths or any(p.startswith(('.moon-treach/','.github/workflows/')) for p in paths): return suites[:]
    return [s for s in suites if s.get('always',False) or any(path_matches(p,g) for p in paths for g in s['paths'])]

def changed_paths(base, head):
    if not base or not head or base==head or not re.fullmatch(r'[0-9a-fA-F]{7,64}',str(base)) or not re.fullmatch(r'[0-9a-fA-F]{7,64}',str(head)): return [],'commit range unavailable; selecting all suites'
    try: p=subprocess.run(['git','diff','--name-only','--diff-filter=ACMR',f'{base}...{head}','--'],cwd=ROOT,text=True,capture_output=True,timeout=30)
    except (OSError,subprocess.TimeoutExpired) as e: return [],f'git diff unavailable ({e}); selecting all suites'
    if p.returncode: return [],f'git diff failed ({p.stderr.strip()[-300:]}); selecting all suites'
    return sorted(set(x.strip().replace('\\','/') for x in p.stdout.splitlines() if x.strip())),None

def cmd_validate(_):
    c=load_config(); print(f"MoonTreach config valid: {c['repository']} ({len(c['suites'])} configured suites)"); return 0

def cmd_plan(a):
    c=load_config(); paths,err=changed_paths(a.base,a.head); chosen=select_suites(c,paths,a.all,err)
    matrix={'include':[{'id':s['id'],'runs_on':s.get('runs_on','ubuntu-latest')} for s in chosen]}; payload=json.dumps(matrix,separators=(',',':')); print(payload)
    if os.getenv('GITHUB_OUTPUT'):
        with open(os.environ['GITHUB_OUTPUT'],'a',encoding='utf-8') as f: f.write(f'matrix={payload}\n')
    if os.getenv('GITHUB_STEP_SUMMARY'):
        with open(os.environ['GITHUB_STEP_SUMMARY'],'a',encoding='utf-8') as f:
            f.write(f"## MoonTreach test plan\n\n- Repository: `{c['repository']}`\n- Changed paths: **{len(paths)}**\n- Selected suites: **{len(chosen)} / {len(c['suites'])}**\n")
            if err: f.write(f'- Conservative fallback: {err}\n')
            if not chosen: f.write('- No configured suite applies; this is not a project-test pass.\n')
            for s in chosen: f.write(f"- `{s['id']}` — {s.get('description','configured check')}\n")
    return 0

def cmd_run(a):
    c=load_config(); s=next((x for x in c['suites'] if x['id']==a.suite),None)
    if not s: raise MoonTreachError(f'Unknown suite: {a.suite}')
    start=time.monotonic(); timeout=s.get('timeout_seconds',1200); print(f"::group::MoonTreach {s['id']}",flush=True)
    try:
        for n,step in enumerate(s['steps'],1):
            cwd=(ROOT/step.get('cwd','.')).resolve()
            if ROOT not in (cwd,*cwd.parents) or not cwd.is_dir(): raise MoonTreachError(f"invalid cwd for {step['name']}: {cwd}")
            print(f"[{n}/{len(s['steps'])}] {step['name']}: {shlex.join(step['command'])}",flush=True)
            try: result=subprocess.run(step['command'],cwd=cwd,timeout=timeout,check=False)
            except subprocess.TimeoutExpired: print(f"TIMEOUT after {timeout}s",file=sys.stderr); return 124
            if result.returncode: print(f"FAILED: {step['name']} (exit {result.returncode})",file=sys.stderr); return result.returncode
        print(f"PASSED: {s['id']} in {time.monotonic()-start:.1f}s",flush=True); return 0
    finally: print('::endgroup::',flush=True)

def normalize_title(title):
    value=title.strip().lower()
    while True:
        old=value
        value=re.sub(r'^draft\s*:\s*','',value)
        value=re.sub(r'^(?:\[[^\]]+\]\s*)+','',value)
        value=re.sub(r'^(?:feat|fix|docs|chore|build|ci|test|refactor)(?:\([^)]*\))?\s*:\s*','',value)
        if old==value: break
    return ' '.join(re.sub(r'[^a-z0-9]+',' ',value).split())

def api_get(url,token):
    headers={'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'MoonTreach/1.0'}
    if token: headers['Authorization']=f'Bearer {token}'
    try:
        with urlopen(Request(url,headers=headers),timeout=20) as r: return json.loads(r.read().decode())
    except HTTPError as e: raise MoonTreachError(f'GitHub API HTTP {e.code}: {url}') from e
    except (URLError,TimeoutError,json.JSONDecodeError) as e: raise MoonTreachError(f'GitHub API request failed: {e}') from e

def cmd_queue(a):
    c=load_config(); token=os.getenv('MOONTREACH_TOKEN') or os.getenv('GITHUB_TOKEN') or os.getenv('GH_TOKEN'); api=os.getenv('GITHUB_API_URL','https://api.github.com').rstrip('/')
    repos=a.repositories or c.get('fleet') or [c['repository']]; prs=[]; errors=[]
    for repo in repos:
        try:
            for page in range(1,a.max_pages+1):
                items=api_get(f'{api}/repos/{repo}/pulls?state=open&per_page=100&page={page}',token)
                if not isinstance(items,list): raise MoonTreachError(f'unexpected response for {repo}')
                prs += [{'repository':repo,'number':p.get('number'),'title':p.get('title',''),'url':p.get('html_url',''),'draft':bool(p.get('draft'))} for p in items]
                if len(items)<100: break
        except MoonTreachError as e: errors.append(f'{repo}: {e}')
    groups=defaultdict(list)
    for p in prs:
        key=normalize_title(p['title'])
        if key: groups[key].append(p)
    repeats=[g for g in groups.values() if len({p['repository'] for p in g})>1]
    report={'repositories_requested':len(repos),'repositories_with_errors':len(errors),'open_prs_observed':len(prs),'repeated_title_candidates':repeats,'errors':errors,'note':'Repeated title is only a review candidate, not proof of duplicate code.'}
    print(json.dumps(report,ensure_ascii=False,indent=2) if a.json else f"MoonTreach PR Radar: {len(prs)} open PRs observed; {len(repeats)} repeated-title groups; {len(errors)} incomplete repositories")
    return 2 if errors else 0

def assess_readiness(pr,checks,statuses):
    failures=[]; pending=[]; evidence=len(checks)+len(statuses)
    for x in checks:
        if x.get('status')!='completed': pending.append(x.get('name','unnamed check'))
        elif x.get('conclusion') not in ('success','neutral','skipped'): failures.append(x.get('name','unnamed check'))
    for x in statuses:
        if x.get('state') in ('failure','error'): failures.append(x.get('context','unnamed status'))
        elif x.get('state')!='success': pending.append(x.get('context','unnamed status'))
    reasons=[]
    state=pr.get('mergeable_state') or 'unknown'
    if pr.get('draft'): reasons.append('pull request is a draft')
    if pr.get('mergeable') is False or state=='dirty': reasons.append('GitHub reports merge conflicts')
    if failures: reasons.append('one or more published checks failed')
    if reasons: verdict='BLOCKED'
    elif pr.get('mergeable') is not True or state in ('unknown','behind','blocked','unstable','draft') or pending or evidence==0:
        verdict='WAITING_FOR_EVIDENCE'
        if pr.get('mergeable') is not True: reasons.append('GitHub has not confirmed mergeability')
        if pending: reasons.append('checks are pending or inconclusive')
        if evidence==0: reasons.append('no check/status evidence was found')
    else: verdict='REVIEW_CANDIDATE'; reasons.append('no published check failures; verify required reviews and repository protection')
    return {'verdict':verdict,'reasons':reasons,'checks':{'total':evidence,'failed':len(failures),'pending':len(pending)}}

def cmd_inspect(a):
    repo=a.repository; token=os.getenv('MOONTREACH_TOKEN') or os.getenv('GITHUB_TOKEN') or os.getenv('GH_TOKEN'); api=os.getenv('GITHUB_API_URL','https://api.github.com').rstrip('/')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',repo) or a.number<1: raise MoonTreachError('provide owner/name and positive PR number')
    pr=api_get(f'{api}/repos/{repo}/pulls/{a.number}',token); sha=(pr.get('head') or {}).get('sha')
    if not sha: raise MoonTreachError('PR response has no head SHA')
    cr=api_get(f'{api}/repos/{repo}/commits/{sha}/check-runs?per_page=100',token); st=api_get(f'{api}/repos/{repo}/commits/{sha}/status',token)
    report=assess_readiness(pr,cr.get('check_runs',[]) if isinstance(cr,dict) else [],st.get('statuses',[]) if isinstance(st,dict) else [])
    report.update({'repository':repo,'number':a.number,'title':pr.get('title'),'url':pr.get('html_url'),'base':(pr.get('base') or {}).get('ref'),'head':(pr.get('head') or {}).get('ref'),'note':'Advisory only. Required-check policy and required approval count are not inferred. No merge action is performed.'})
    print(json.dumps(report,ensure_ascii=False,indent=2) if a.json else f"{repo}#{a.number}: {report['verdict']}\n"+'\n'.join('- '+x for x in report['reasons'])+'\nNo merge action was taken.')
    return 0 if report['verdict']=='REVIEW_CANDIDATE' else 1

def parser():
    p=argparse.ArgumentParser(description='MoonTreach safe test accelerator and read-only PR radar'); sub=p.add_subparsers(dest='command',required=True)
    v=sub.add_parser('validate'); v.set_defaults(func=cmd_validate)
    q=sub.add_parser('plan'); q.add_argument('--base'); q.add_argument('--head'); q.add_argument('--all',action='store_true'); q.set_defaults(func=cmd_plan)
    r=sub.add_parser('run'); r.add_argument('suite'); r.set_defaults(func=cmd_run)
    q=sub.add_parser('queue'); q.add_argument('--repositories',nargs='*'); q.add_argument('--max-pages',type=int,default=5); q.add_argument('--json',action='store_true'); q.set_defaults(func=cmd_queue)
    i=sub.add_parser('inspect-pr'); i.add_argument('repository'); i.add_argument('number',type=int); i.add_argument('--json',action='store_true'); i.set_defaults(func=cmd_inspect)
    return p

def main(argv=None):
    a=parser().parse_args(argv)
    if a.command=='queue' and not 1<=a.max_pages<=20: raise SystemExit('--max-pages must be in range 1..20')
    try: return a.func(a)
    except MoonTreachError as e: print(f'MoonTreach: {e}',file=sys.stderr); return 2

if __name__=='__main__': raise SystemExit(main())
